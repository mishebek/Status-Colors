Hooks.once("init", () => {
    CONFIG.DND5E.conditionTypes.bleeding.img = "bleeding.png";
});

Hooks.once("init", () => {
    CONFIG.DND5E.conditionTypes.blinded.img = "blinded.png";
});

Hooks.once("init", () => {
    CONFIG.DND5E.conditionTypes.burning.img = "burning.png";
});

Hooks.once("init", () => {
    CONFIG.DND5E.conditionTypes.burrowing.img = "burrowing.png";
});

Hooks.once("init", () => {
    CONFIG.DND5E.conditionTypes.charmed.img = "charmed.png";
});

Hooks.once("init", () => {
    CONFIG.DND5E.conditionTypes.concentrating.img = "concentrating.png";
});

Hooks.once("init", () => {
    CONFIG.DND5E.conditionTypes.coverhalf.img = "cover-half.png";
});

Hooks.once("init", () => {
    CONFIG.DND5E.conditionTypes.coverthreequarters.img = "cover-three-quarters.png";
});

Hooks.once("init", () => {
    CONFIG.DND5E.conditionTypes.covertotal.img = "cover-total.png";
});